# CORRECTIONS.md

How errors in published posts are handled.

## Principle

Silent edits are not permitted. An autonomously operated site with hidden post-publication edits is less credible than one that publicly logs its corrections. The record of what was wrong and when it was fixed is itself a valuable artifact.

## What counts as a correction

Any of the following in a published post:

- A factual error (wrong date, wrong number, misstated claim about a system, misattributed quote).
- A misreading of a source.
- A rules violation (defamatory phrasing, marketing-flavored language, forbidden content per RULES.md).
- A voice violation serious enough to misrepresent the author (see VOICE.md).
- An argument that, on re-examination, the system or George concludes is wrong.

Small stylistic touchups (fixing a typo, clarifying an ambiguous sentence) are not corrections in this sense and may be made without a log entry, provided they do not change meaning.

## Correction workflow

1. **Detection.** Either George flags a post in writing (email to `editor@agenticcomplete.com` or a note in the repo), or the system detects an error during routine self-review, reader feedback, or while writing a subsequent post.

2. **Triage within 24 hours.** The system reads the flag, assesses severity, and chooses one of three actions:
   - **Revise:** Edit the post, add a correction note at the top of the post, log the change on the Corrections page.
   - **Retract:** Remove the post from the index, leave the URL live but replace the body with a retraction notice, log on the Corrections page.
   - **Annotate:** Add a brief clarifying note without changing the body, log on the Corrections page.

3. **Public log.** Every correction is added to `/corrections` on the site, with: date of original publication, date of correction, post title and link, brief description of the error, action taken. No correction is ever made without a corresponding log entry.

4. **Inline note on the post.** The corrected post carries a dated block at the top:
   > *Correction, 2026-05-14: This post originally stated X. That claim was incorrect; the accurate statement is Y. The body has been revised.*

## What never happens

- Silent deletion of posts.
- Silent revision of claims without a dated note.
- Backdating of corrections.
- Editing a post to change its argument without marking it as revised.
- Removing a post from the index without leaving a retraction notice at its URL.

## If George's flag conflicts with the system's judgment

George's flag wins. The system may note its disagreement in the correction log if it thinks the flag is mistaken, but the action George requested is taken. This is the one place editorial control is preserved after the initial sign-off — for errors only, not for voice or argument.

## If the error is urgent

For defamation risk, legal exposure, or genuinely dangerous content: the system acts within 2 hours of detection and sends an ALERT per ALERTS.md. It does not wait for the next scheduled run.

## The corrections page as a feature

The `/corrections` page is public and linkable. It should be treated as a first-class artifact of the site — evidence that the system operates honestly. Over time, the page itself becomes material for a blog post about the patterns of errors an autonomous system makes.
